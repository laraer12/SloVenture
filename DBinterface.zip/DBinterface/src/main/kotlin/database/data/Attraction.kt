package database.data

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

@Serializable
data class Attraction(
    val id: String,
    val name: String,
    val regionId: String,
    val location: Coordinates,
    val address: Address,
    val description: String?,
    val classification: String,
    val locationType: String,
    val elevation: Double,
    val accessibilityOptions: String?,
    val ratingFamilyFriendly: Double,
    val ratingElderlyFriendly: Double,
    val ratingAccessible: Double,
    val rating: Double,
    val requiresReservation: Boolean,
    val openingHours: OpeningHours,
    val entryFee: Double,
    val googleMapsLink: String,
    val createdAt: String? = null,
    val verified: Boolean
)

@Serializable
data class Coordinates(
    val lat: Double,
    val lon: Double
)

@Serializable
data class Address(
    val street: String,
    val city: String,
    val postalCode: String,
    val country: String
)


@Serializable
data class OpeningHours(
    val monday: String,
    val tuesday: String,
    val wednesday: String,
    val thursday: String,
    val friday: String,
    val saturday: String,
    val sunday: String
)

/*
val client = OkHttpClient()
val json = Json { ignoreUnknownKeys = true }

fun getAttractions(): List<Attraction> {
    val request = Request.Builder()
        .url("http://localhost:3000/api/attractions") // your web service URL
        .build()

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Unexpected code $response")

        val body = response.body?.string() ?: return emptyList()
        return json.decodeFromString(ListSerializer(Attraction.serializer()), body)
    }
}
*/

//povezava z web service
val json = Json { ignoreUnknownKeys = true }
val client = OkHttpClient()

suspend fun getAllAttractions(): List<Attraction>? {
    val request = Request.Builder()
        .url("http://localhost:3001/api/attractions")
        .get()
        .build()

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            println("GET failed: ${response.code}")
            return null
        }

        val body = response.body?.string() ?: return null
        return json.decodeFromString<List<Attraction>>(body)
    }
}

suspend fun postAttraction(attraction: Attraction): Boolean {
    val jsonAttraction = json.encodeToString(Attraction.serializer(), attraction)
    val mediaType = "application/json".toMediaType()
    val body = jsonAttraction.toRequestBody(mediaType)

    // 🔍 Print the raw JSON string you’re sending
    println("🟡 JSON payload being sent:\n$jsonAttraction")

    val request = Request.Builder()
        .url("http://localhost:3001/attractions")
        .post(body)
        .build()

    // 🔍 Print request metadata
    println("🔵 Request details:")
    println("  Method: ${request.method}")
    println("  URL: ${request.url}")
    println("  Headers: ${request.headers}")

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            println("POST failed: ${response.code}")
            return false
        }

        return true
    }
}

suspend fun getAttractionsByRegion(regionId: String): List<Attraction>? {
    val request = Request.Builder()
        .url("http://localhost:3001/api/attractions/region/$regionId")
        .get()
        .build()

    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            println("GET by region failed: ${response.code}")
            return null
        }

        val body = response.body?.string() ?: return null
        return json.decodeFromString<List<Attraction>>(body)
    }
}

suspend fun updateAttraction(id: String, updated: Attraction): Boolean {
    val jsonAttraction = json.encodeToString(Attraction.serializer(), updated)
    val body = jsonAttraction.toRequestBody("application/json".toMediaType())

    val request = Request.Builder()
        .url("http://localhost:3001/api/attractions/$id")
        .put(body)
        .build()

    client.newCall(request).execute().use { response ->
        return response.isSuccessful
    }
}

suspend fun deleteAttraction(id: String): Boolean {
    val request = Request.Builder()
        .url("http://localhost:3001/api/attractions/$id")
        .delete()
        .build()

    client.newCall(request).execute().use { response ->
        return response.isSuccessful
    }
}

